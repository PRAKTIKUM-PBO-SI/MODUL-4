
package LatihanGui;

/**
teddy putratama
* 2211103067
* 07C
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RandomMotivasi {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Motivasi Buat hari ini");
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        
        JLabel label = new JLabel("Kutipan Motivasi Hari Ini:");
        label.setFont(new Font("Serif", Font.BOLD, 18));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JTextArea quoteArea = new JTextArea("Klik tombol untuk dapatkan motivasi");
        quoteArea.setFont(new Font("Serif", Font.ITALIC, 16));
        quoteArea.setEditable(false);
        quoteArea.setLineWrap(true);
        quoteArea.setWrapStyleWord(true);
        quoteArea.setBackground(new Color(245, 245, 245));
        quoteArea.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        
        JButton refreshButton = new JButton("Dapatkan Motivasi Baru");
        refreshButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        refreshButton.addActionListener(new ActionListener() {
            String[] quotes = {
                "Jangan berhenti hanya karena lelah, berhentilah jika sudah selesai. Kamu lebih kuat dari yang kamu pikirkan",
                "Setiap langkah kecil hari ini adalah pondasi untuk kesuksesan besar esok hari. Tetap semangat",
                "Hidup adalah tentang terus mencoba, bukan tentang menyerah. Kamu pasti bisa!",
                "dah ah cape."
            };
            @Override
            public void actionPerformed(ActionEvent e) {
                int randomIndex = (int) (Math.random() * quotes.length);
                quoteArea.setText(quotes[randomIndex]);
            }
        });

        panel.add(label);
        panel.add(Box.createRigidArea(new Dimension(0, 10))); 
        panel.add(quoteArea);
        panel.add(Box.createRigidArea(new Dimension(0, 10))); 
        panel.add(refreshButton);

        frame.getContentPane().add(panel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setVisible(true);
    }
}
